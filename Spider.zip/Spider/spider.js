var http = require('http'),
  fs = require('fs'),
  cheerio = require('cheerio'),
  request = require('request'),
  Proxy = require('./proxylist.js');


const url = "http://www.wic.edu.cn";



var log = console.info.bind(console);


var options = {
  //hostname:'www.zhihu.com/explore',
  hostname: 'http://www.wic.edu.cn',
  path: '/',
  proxy: Proxy.GetProxy(),
  port: '80',
  method: 'GET',
  header: {
    'User-Agent': 'wilson'
  }
};

/*

function  dataRequest(){

request(options, function(err,res,body) {
  var html = '';

  var titles=[];

  //res.setEncoding('utf-8');

  res.on('data', function(chunk) {
    html += chunk;
  });


  res.on('end', function() {
    var $ = cheerio.load(html);

    var titleArr = $('.newsList_bd  a').text().trim();

    $(".newsList_bd  a").each(function(i, e) {
        titles.push($(e).text());
    });

    log(titles);
  });

   }).on('error', function(err) {
    log(err+' Spider meets error , please wait..... ');
  });


}


dataRequest();
*/





function startRequest(url) {
    http.get(url,function (res) {   

        //log(options)

        var html = '';         
        var titles = [];        
        res.setEncoding('utf-8'); 


        //监听data事件，每次取一块数据
        res.on('data', function (chunk) {   
            html += chunk;
        });

        //监听end事件，如果整个网页内容的html都获取完毕，就执行回调函数
        res.on('end', function () {

        var $ = cheerio.load(html); //采用cheerio模块解析html
         
         
        var  titleArr = $('.newsList_bd  a').text().trim();

         $(".newsList_bd  a").each(function(i, e) {
              titles.push($(e).text());

              //savedContent($,titleArr);
        });
  

        log(titles)

        /*for(var x in titleArr) {
            log(titleArr[x]);
        }*/

        savedContent($,titleArr);  //存储每篇文章的内容及文章标题

        savedImg($,titleArr);    //存储每篇文章的图片及图片标题

     });

    }).on('error', function () {
         log(' Spider meets error , please wait..... ');
    });
   
}







//该函数的作用：在本地存储所爬取的新闻内容资源

function savedContent($, titleArr) {
        fs.appendFile('./data/content.txt', titleArr , 'utf-8', function (err) {
            if (err) {
                log(' writing  file  meets  errors . ');
            }
        });

}


//该函数的作用：在本地存储所爬取到的图片资源

function savedImg($,news_title) {
    $('.article-content img').each(function (index, item) {
        var img_title = $(this).attr('alt');  //获取图片的标题
        if(img_title.length>35||img_title==""){
         img_title="Null";}
        var img_filename = img_title + '.jpg';

        var img_src = 'https://huxiu.com' + $(this).attr('data-original'); //获取图片的url

        //采用request模块，向服务器发起一次请求，获取图片资源
        request.head(img_src,function(err,res,body){
            if(err){
                console.log(err);
            }
        });
        request(img_src).pipe(fs.createWriteStream('./image/'+news_title + '---' + img_filename));     //通过流的方式，把图片写到本地/image目录下，并用新闻的标题和图片的标题作为图片的名称。
    })
}


setInterval(function  _main(){
      startRequest(url); 
},1000);     //主程序开始运行
 
