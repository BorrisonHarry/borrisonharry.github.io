var http = require('http'),
  fs = require('fs'),
  cheerio = require('cheerio'),
  request = require('request');



/*var postData = querystring.stringify({
  'msg' : 'Hello World!'
});*/
var options = {
  hostname: 'www.baidu.com',
  port: 80,
  path: '/upload',
  method: 'POST',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
   // 'Content-Length': postData.length
  }
};


var log=console.info.bind(console);

var req = http.request(options, (res) => {
  
  var  html='';
  
  res.setEncoding('utf8');
  
  res.on('data', (chunk) => {
      html+=chunk;
  });
  
  res.on('end', () => {
	var $ = cheerio.load(html);
	
	log($);
	
    log('No more data in response.')
  })
  
}).on('error',(e)=>{
	log(`problem with request: ${e.message}`);
});

req.end();